var _publisher = "Haaretz";

