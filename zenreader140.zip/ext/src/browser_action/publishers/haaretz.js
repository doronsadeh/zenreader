var _publisher = "Haaretz";

